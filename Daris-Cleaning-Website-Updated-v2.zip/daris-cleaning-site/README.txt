DARIS CLEANING WEBSITE — VERCEL STATIC SITE

Files:
- index.html (single-file multilingual site: HTML, CSS and JS)
- logo.svg, favicon.svg, sitemap.xml, robots.txt
- images/hero/hero-illustration.webp
- images/services/ (individually assigned service photos and unique illustration fallbacks)

Individually assigned photographs:
home-cleaning.jpg, shop-cleaning.jpg, stairwell-cleaning.jpg,
window-cleaning.jpg, restaurant-cleaning.jpg, school-cleaning.jpg,
retail-work.jpg, deep-cleaning.jpg, move-out-cleaning.jpg.

Office, daycare and post-construction each use their own distinct illustration because no matching supplied photo was available. No service reuses another service's image.

Vercel:
- Framework Preset: Other
- Root Directory: ./
- Build Command: leave empty
- Output Directory: . (or leave override off)
- Install Command: leave empty
- vercel.json rewrites clean language routes to index.html

Before launch:
- Confirm business phone, email, service area, opening hours and form endpoint in CONFIG.
- The form needs a real Formspree/Netlify endpoint before it can submit messages.
- Test Finnish, Swedish and English routes after deployment.
